import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  // Carrega variáveis de ambiente baseadas no modo (development/production)
  // O terceiro argumento '' garante que carregamos todas as vars, não apenas as com prefixo VITE_
  const env = loadEnv(mode, process.cwd(), '');

  return {
    plugins: [react()],
    define: {
      // Isso permite usar process.env.API_KEY no código frontend,
      // mapeando para o valor de VITE_API_KEY configurado na Vercel
      'process.env.API_KEY': JSON.stringify(env.VITE_API_KEY)
    }
  };
});