import React, { useState } from 'react';
import { Button } from './Button';
import { User, AppView } from '../types';

interface LoginFormProps {
  onLogin: (user: User) => void;
  onCancel: (view: AppView) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onLogin, onCancel }) => {
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;

    setIsLoading(true);

    // Simulate network delay for login
    setTimeout(() => {
      onLogin({
        username: username,
        role: 'member'
      });
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
      <div className="w-full max-w-md bg-slate-800/50 backdrop-blur-md border border-slate-700 p-8 rounded-2xl shadow-2xl">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white">Bem-vindo de volta</h2>
          <p className="text-slate-400 mt-2">Entre para acessar o assistente Gemini.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-slate-300 mb-2">
              Nome de Usuário
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-slate-900/50 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              placeholder="Digite seu nome (ex: DevUser)"
              required
            />
          </div>

          <div className="flex flex-col gap-3">
            <Button type="submit" isLoading={isLoading} className="w-full py-3">
              Entrar na Área de Membros
            </Button>
            <Button 
              type="button" 
              variant="ghost" 
              onClick={() => onCancel(AppView.LANDING)}
              className="w-full"
            >
              Voltar para Home
            </Button>
          </div>
        </form>
        
        <p className="mt-6 text-center text-xs text-slate-500">
          *Este é um login simulado. Nenhuma senha real é necessária.
        </p>
      </div>
    </div>
  );
};