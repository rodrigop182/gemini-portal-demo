import React from 'react';
import { User, AppView } from '../types';
import { Button } from './Button';

interface NavbarProps {
  user: User | null;
  onNavigate: (view: AppView) => void;
  onLogout: () => void;
  currentView: AppView;
}

export const Navbar: React.FC<NavbarProps> = ({ user, onNavigate, onLogout, currentView }) => {
  return (
    <nav className="w-full border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div 
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => onNavigate(AppView.LANDING)}
          >
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <span className="text-white font-bold text-lg">G</span>
            </div>
            <span className="font-bold text-xl tracking-tight text-white">Gemini<span className="text-indigo-400">Portal</span></span>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-4">
                <span className="hidden sm:block text-sm text-slate-400">
                  Olá, <span className="text-white font-medium">{user.username}</span>
                </span>
                {currentView !== AppView.DASHBOARD && (
                   <Button variant="ghost" onClick={() => onNavigate(AppView.DASHBOARD)} className="text-sm">
                     Dashboard
                   </Button>
                )}
                <Button variant="outline" onClick={onLogout} className="text-sm py-2 px-4">
                  Sair
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                {currentView !== AppView.LOGIN && (
                  <>
                    <button 
                      onClick={() => onNavigate(AppView.LOGIN)}
                      className="text-slate-300 hover:text-white text-sm font-medium transition-colors"
                    >
                      Login
                    </button>
                    <Button onClick={() => onNavigate(AppView.LOGIN)} className="text-sm py-2 px-4">
                      Começar Agora
                    </Button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};