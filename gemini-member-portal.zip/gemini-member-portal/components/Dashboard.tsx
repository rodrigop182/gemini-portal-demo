import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage } from '../types';
import { generateAIResponse } from '../services/geminiService';
import { Button } from './Button';

interface DashboardProps {
  user: User;
}

export const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `Olá ${user.username}! Eu sou seu assistente virtual powered by Gemini. Como posso ajudar você hoje?`,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputValue.trim() || isProcessing) return;

    const userText = inputValue;
    setInputValue('');
    
    // Add user message
    const newUserMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: userText,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newUserMsg]);
    setIsProcessing(true);

    // Call Gemini API
    const aiText = await generateAIResponse(userText);

    const newAiMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: aiText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newAiMsg]);
    setIsProcessing(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 h-[calc(100vh-64px)] flex flex-col">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Dashboard de Membro</h2>
          <p className="text-slate-400">Integração ativa: <span className="text-indigo-400 font-medium">Gemini 2.5 Flash</span></p>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="flex-1 bg-slate-800/30 backdrop-blur border border-slate-700 rounded-2xl overflow-hidden flex flex-col shadow-inner">
        
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] md:max-w-[70%] rounded-2xl px-5 py-4 ${
                  msg.role === 'user' 
                    ? 'bg-indigo-600 text-white rounded-br-none' 
                    : 'bg-slate-700/50 text-slate-200 rounded-bl-none border border-slate-600'
                }`}
              >
                <div className="whitespace-pre-wrap leading-relaxed">{msg.text}</div>
                <div className={`text-xs mt-2 opacity-50 ${msg.role === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {msg.role === 'model' ? 'Gemini AI' : 'Você'} • {msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-slate-800 border-t border-slate-700">
          <form onSubmit={handleSendMessage} className="relative flex items-center gap-3">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Digite sua mensagem para a IA..."
              disabled={isProcessing}
              className="flex-1 bg-slate-900 border border-slate-600 rounded-xl px-4 py-4 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
            />
            <Button 
              type="submit" 
              disabled={!inputValue.trim() || isProcessing}
              className="h-[58px] px-6 rounded-xl"
            >
              {isProcessing ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              )}
            </Button>
          </form>
          <p className="text-center text-xs text-slate-600 mt-2">
            A IA pode gerar informações imprecisas. Verifique informações importantes.
          </p>
        </div>
      </div>
    </div>
  );
};