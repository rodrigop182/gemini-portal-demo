import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { LandingHero } from './components/LandingHero';
import { LoginForm } from './components/LoginForm';
import { Dashboard } from './components/Dashboard';
import { User, AppView } from './types';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setCurrentView(AppView.DASHBOARD);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView(AppView.LANDING);
  };

  const handleNavigate = (view: AppView) => {
    if (view === AppView.DASHBOARD && !user) {
      setCurrentView(AppView.LOGIN);
      return;
    }
    setCurrentView(view);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 font-sans selection:bg-indigo-500/30">
      <Navbar 
        user={user} 
        onLogout={handleLogout} 
        onNavigate={handleNavigate}
        currentView={currentView}
      />
      
      <main>
        {currentView === AppView.LANDING && (
          <LandingHero onNavigate={handleNavigate} />
        )}

        {currentView === AppView.LOGIN && (
          <LoginForm 
            onLogin={handleLogin} 
            onCancel={handleNavigate}
          />
        )}

        {currentView === AppView.DASHBOARD && user && (
          <Dashboard user={user} />
        )}
      </main>

      {/* Simple Footer */}
      <footer className="border-t border-slate-800 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Gemini Member Portal. Projeto de Teste.</p>
          <p className="mt-2">Feito com React, Tailwind e Google Gemini API.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;