import { GoogleGenAI } from "@google/genai";

// Initialize the API client.
// The API key must be obtained exclusively from the environment variable process.env.API_KEY.
// We cast as string to satisfy TypeScript since we are now using @types/node
const ai = new GoogleGenAI({ apiKey: (process.env.API_KEY as string) });

export const generateAIResponse = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "Você é um assistente virtual útil e educado para uma área de membros exclusiva. Responda em português de forma concisa e amigável.",
      }
    });

    if (response.text) {
        return response.text;
    }
    
    return "Não consegui gerar uma resposta no momento.";
  } catch (error: any) {
    console.error("Erro na API Gemini:", error);
    return `Desculpe, ocorreu um erro ao processar sua solicitação. Detalhes: ${error.message || 'Erro desconhecido'}`;
  }
};